//
//  customCell.swift
//  Spotify
//
//  Created by Emily Bertschinger on 2/12/16.
//  Copyright © 2016 USU. All rights reserved.
//

import UIKit

class customCell: UITableViewCell {

    @IBOutlet weak var imageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
